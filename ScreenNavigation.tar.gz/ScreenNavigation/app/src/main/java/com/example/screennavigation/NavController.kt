package com.example.screennavigation

class NavController {
}